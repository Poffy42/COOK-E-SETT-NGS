// Geçici olarak saklanacak değişkenler
let tempPreferences = {
    functional: false,
    marketing: false
};

// Toggle switch'in durumunu günceller
function toggleSwitch(section, event) {
    event.stopPropagation(); // Olayın yukarıya taşınmasını engelle
    const switchElement = document.querySelector(`.${section}-switch`);
    
    // Toggle switch durumunu değiştir
    switchElement.classList.toggle('on');

    // Geçici tercihleri güncelle
    tempPreferences[section] = switchElement.classList.contains('on');
}

// Kullanıcı tercihlerlerini günceller
function updatePreferences() {
    // Geçici tercihleri kullanarak güncelle
    savePreferences(tempPreferences);
}

// “Ayarlarımı Kaydet” butonuna tıklanıldığında
document.querySelector('.save-button').addEventListener('click', function() {
    updatePreferences();
});

// Modal'ı açmak için fonksiyon
function openModal() {
    document.getElementById("cookieModal").style.display = "block";
    document.getElementById("modalOverlay").style.display = "block";
    document.body.classList.add('modal-open');
    document.body.style.overflow = 'hidden';
    // Başlangıçta "Ayarlarınızı Düzenleyin" tab'ını aktif yap
    showTab('settings');
    hideCookieConsent();
}

// Modal'ı kapatmak için fonksiyon
function closeModal() {
    document.getElementById("cookieModal").style.display = "none";
    document.getElementById("modalOverlay").style.display = "none";
    document.body.classList.remove('modal-open');
    document.body.style.overflow = 'auto';
    // Yükseklik ve opaklık değerlerini sıfırla
    const sections = document.querySelectorAll('.section-content');
    sections.forEach(sec => {
        sec.style.maxHeight = null;
        sec.style.opacity = 0;
    });
}

// Çerez kabul etme işlemi
function acceptCookies() {
    const preferences = {
        necessary: true,
        functional: true,
        marketing: true
    };
    savePreferences(preferences);
    hideCookieConsent();
}

function rejectCookies() {
    const preferences = {
        necessary: true,
        functional: false,
        marketing: false
    };
    savePreferences(preferences);
    hideCookieConsent();
}

function hideCookieConsent() {
    document.getElementById("cookieConsent").style.display = "none";
}

function toggleSection(sectionId) {
    const section = document.getElementById(sectionId);
    
    // Sekmenin açılıp açılmadığını kontrol et
    if (section.style.maxHeight) {
        // Zaten açık, kapat
        section.style.maxHeight = null;
        section.style.opacity = 0;
    } else {
        // Kapalı, aç
        const sections = document.querySelectorAll('.section-content');
        sections.forEach(sec => {
            sec.style.maxHeight = null;
            sec.style.opacity = 0;
        });
        
        section.style.maxHeight = section.scrollHeight + "px";
        section.style.opacity = 1;
    }
}

// Tab'ı göstermek için fonksiyon
function showTab(tabId) {
    // Tüm tab'ların seçili stilini kaldır
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(tab => {
        tab.classList.remove('active');
    });

    // Seçili tab'ın stilini ayarla
    const selectedTab = document.querySelector(`.tab[onclick*="${tabId}"]`);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }

    // Tüm tab içeriklerini gizle
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(tabContent => tabContent.classList.remove('active'));

    // Tıklanan tab'ı göster
    document.getElementById(tabId).classList.add('active');
}

// Çerez açıklamalarını gösterip gizlemek için fonksiyon
function toggleDescription(toggle) {
    const description = toggle.nextElementSibling;
    description.style.display = toggle.checked ? "block" : "none";
}

function savePreferences(preferences) {
    fetch('/save-cookie-preferences.php', {  // Kök dizindeki PHP dosyasına istek gönderiyoruz BURAYI GEREKİRSE DEĞİŞ
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(preferences)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === "success") {
            alert("Tercihler kaydedildi!");
            closeModal(); // Modal pencereyi kapat
        } else {
            alert("Tercihler kaydedilirken bir hata oluştu.");
        }
    })
    .catch(error => {
        console.error('Hata:', error);
        alert("Tercihler kaydedilirken bir hata oluştu.");
    });
}

function loadPreferences() {
    fetch('/get-cookie-preferences.php')  // Kök dizindeki PHP dosyasından verileri alıyoruz BURAYI GEREKİRSE DEĞİŞ
        .then(response => response.json())
        .then(data => {
            // Kullanıcı tercihlerini işleme
            console.log(data);
            // Switch durumlarını ayarla
            if (data.functional) {
                document.querySelector('.functional-switch').classList.add('on');
            }
            if (data.marketing) {
                document.querySelector('.marketing-switch').classList.add('on');
            }
        })
        .catch(error => {
            console.error('Hata:', error);
        });
}

function checkCookieConsent() {
    const cookieConsent = getCookie('cookie_preferences');

    if (cookieConsent) {
        try {
            const preferences = JSON.parse(cookieConsent);
            // Eğer gerekli çerezler varsa, consent penceresini kapat
            if (preferences.necessary) {
                document.getElementById("cookieConsent").style.display = "none";
                document.getElementById("cookieModal").style.display = "none"; // Eğer modal da kapalı olmalıysa
            } else {
                document.getElementById("cookieConsent").style.display = "block";
            }
        } catch (e) {
            console.error("Çerez verisini çözümleme hatası:", e);
        }
    } else {
        document.getElementById("cookieConsent").style.display = "block";
    }
}


// Çerezi almak için yardımcı fonksiyon
// Çerezi almak için yardımcı fonksiyon
function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) {
        // URL kod çözme işlemi
        return decodeURIComponent(parts.pop().split(';').shift());
    }
    return null;
}

document.addEventListener("DOMContentLoaded", function() {
    checkCookieConsent();
});


// Sayfa yüklendiğinde çerez tercihlerini kontrol et 2. defa kontrol için
window.onload = function() {
    checkCookieConsent();
};
