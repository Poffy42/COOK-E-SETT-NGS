<?php
// CORS ve içerik türü ayarları
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// JSON dosyasının yolu DEĞİŞTİRMEEEEEEEEEEEEEEYİ UUUUUUUUUUUUUUUUNUTMA
$jsonFilePath = __DIR__ . '/cookie-preferences.json';

// Kullanıcı IP'sine göre tercihler alınacak
$userId = $_SERVER['REMOTE_ADDR']; // Kullanıcının IP adresi

// Dosya mevcutsa veriyi oku
if (file_exists($jsonFilePath)) {
    $existingData = file_get_contents($jsonFilePath);
    if ($existingData === false) {
        echo json_encode(['status' => 'error', 'message' => 'Dosya okunamadı.']);
        exit;
    }
    $jsonData = json_decode($existingData, true);
    if ($jsonData === null) {
        echo json_encode(['status' => 'error', 'message' => 'JSON verisi geçersiz.']);
        exit;
    }

    // Kullanıcının tercihleri varsa bunları döndür
    if (isset($jsonData[$userId])) {
        echo json_encode($jsonData[$userId]);
    } else {
        // Eğer dosya mevcut ama kullanıcı tercihleri bulunmuyorsa
        echo json_encode(['status' => 'error', 'message' => 'Kullanıcı tercihleri bulunamadı.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'JSON dosyası bulunamadı.']);
}
?>
