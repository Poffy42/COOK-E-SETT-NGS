<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

// POST isteği ile gelen verileri al
$data = json_decode(file_get_contents("php://input"), true);

// Hata kontrolü: Gönderilen veri boş mu?
if ($data === null) {
    echo json_encode(["status" => "error", "message" => "Geçersiz veri"]);
    exit;
}

// Çerezlere kaydedildiği zamanı da ekleyin
$data['timestamp'] = time(); // Mevcut zaman damgasını ekleyin
// Varsayılan 'necessary' alanını ekleyin, eğer veri yoksa
if (!isset($data['necessary'])) {
    $data['necessary'] = true;
}
// JSON dosyasının yolu BURAYI DEĞİŞTİRMEYİ UNUTMAaaaaaaaaaaaAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
$jsonFilePath = __DIR__ . '/cookie-preferences.json';

// Çerezi ayarlamak için setcookie fonksiyonunu kullanın
// Çerezlerin özelliklerini ayarlamak için setcookie fonksiyonunu kullanın
$expiry = time() + (86400 * 30); // 30 gün boyunca geçerli
$path = "/";
$domain = ""; // Ana alan adı belirtin veya boş bırakabilirsiniz
$secure = true; // HTTPS üzerinden güvenli
$httponly = true; // JavaScript ile erişimi engelle
$samesite = 'Lax'; // SameSite ayarı: Lax, Strict, veya None

setcookie(
    'cookie_preferences', // Çerez adı
    json_encode($data),   // Çerezin değeri
    [
        'expires' => $expiry,  // Çerezin süresi
        'path' => $path,        // Çerezin geçerli olduğu yol
        'domain' => $domain,    // Çerezin geçerli olduğu alan adı
        'secure' => $secure,    // HTTPS üzerinden güvenli
        'httponly' => false, // JavaScript ile erişimi engelle
        'samesite' => $samesite // SameSite ayarı
    ]
);

// POST isteği ile gelen çerez tercihlerini al
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // JSON formatında gelen veriyi al
    $inputJSON = file_get_contents('php://input');
    $preferences = json_decode($inputJSON, true);

    // Dosyadan mevcut verileri oku
    if (file_exists($jsonFilePath)) {
        $existingData = file_get_contents($jsonFilePath);
        $jsonData = json_decode($existingData, true);
    } else {
        $jsonData = [];
    }

    // Kullanıcı tercihlerini ID'ye göre saklayın (örneğin, IP adresi veya kullanıcı kimliği)
    $userId = $_SERVER['REMOTE_ADDR']; // Kullanıcının IP adresini kullanıyoruz
    $jsonData[$userId] = $preferences;

    // Yeni veriyi JSON dosyasına yaz
    file_put_contents($jsonFilePath, json_encode($jsonData, JSON_PRETTY_PRINT));

    // Başarılı olduğuna dair cevap gönder
    echo json_encode(['status' => 'success']);
} else {
    // POST isteği değilse hata döndür
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Yalnızca POST istekleri kabul edilir.']);
}
?>
